# read the csv file to a dataframe
df <- read.csv("/Users/bernairemari/Desktop/MigrantLocal.csv")
#Check ggplot2 documentation for drawing different types of plots
install.packages("ggplot2")
library('ggplot2')
library('MASS')
# use ggplot2 to draw density for two groups
ggplot(df) + geom_density(aes(x=mobdistance, colour=surveytype)) + 
  ggtitle('Density of Mobility Distance for Migrants and Locals')
# Apply box cox transformation
b=boxcox(mobdistance~surveytype, data=df)
I=which(b$y==max(b$y))
lambda=b$x[I]
# Add one column to record the transformed values.
df$postboxcox <- (df$mobdistance^lambda-1)/lambda
# check the transformed values
ggplot(df) + 
  geom_density(aes(x=postboxcox, colour=surveytype)) + 
  ggtitle('Density of Mobility Distance')
