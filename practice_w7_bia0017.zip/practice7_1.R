#1. Randomly use a dataset you are interested.
library('ggplot2')
library('MASS')
data("iris")
#2. Draw density plots for two variables
ggplot(iris, aes(x = Sepal.Length)) +
  geom_density()

ggplot(iris, aes(x = Petal.Width)) +
  geom_density()

I created density plots for two variables in the "iris" dataset. The density
graphs show that the variable "Sepal.Length" has a normal distribution. 
In contrast, the variable "Petal.Width" has a bimodal distribution.

#3. Conduct a visualization analysis.
ggplot(iris, aes(x = Petal.Length, y = Petal.Width, color = Species)) +
  geom_point() +
  labs(x = "Petal Length", y = "Petal Width", color = "Species")

From the scatter plot, I found that setosa is the smallest species. In
contrast, virginicia is the largest species. From this scatter plot, I can
assume that as the petal width increases, the petal length also increases.