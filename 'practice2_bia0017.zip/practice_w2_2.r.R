#Randomly create a vector with grade of students: A,B,C,D,E,F,G,H
course.grades <- c(76,97,68,92,88,56,90,84)
students <- c('A','B','C','D','E','F','G','H')
names(course.grades) <- students
#Cut the grades into 3 ranges.
grade.range <- cut(course.grades,3)

#How many students in each range?
table(grade.range )
#Statistical description of the grades.
summary(course.grades)
#Who have grade less than 60?
course.grades[course.grades<60]
