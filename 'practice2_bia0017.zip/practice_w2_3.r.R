l <- list(x = 1:5, y = c("a","b"), z ="this is string")
#Get z and check the type
l[[3]]
typeof(l[[3]])
str(l$z)
#Get the vector y and check the type
l[[2]]
typeof(l[[2]])
str(l$y)
#Get the second element of x and check the type
l[[1]][2]
str(l[[1]][2])
typeof(l[[1]][2])
