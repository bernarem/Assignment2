a <- 15
N = "Hello World"
a
N

#check type of a
typeof(a)
#change a to strings
as.character(a)
#check type of a
typeof(a)


#create object b
b <- a + 10
#square root of b
sqrt(b)
#log of b
log(b)
