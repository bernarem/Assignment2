#in-class practice 1

install.packages('psych')
library(psych)
#read file
electric_vehicle <- read.csv("/Users/bernairemari/Desktop/Electric_Vehicle_Population_Data.csv")
#first 5 lines
head(electric_vehicle, 5)
#statistical summary
summary(electric_vehicle)



