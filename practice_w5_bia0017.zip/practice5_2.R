# install the packages
install.packages("rjson")
install.packages("jsonlite")
# load the packages
library('rjson')
library('jsonlite')
# find the directory where your file is saved
setwd("/Users/bernairemari/Desktop")
# read the file with stream_in
json_file <- "snowstorm_sample2.json"
storm_tweets <- stream_in(file(json_file))
# check the dimension of storm_tweets
nrow(storm_tweets)
ncol(storm_tweets)
#extract the elements from storm tweets.
date_time = storm_tweets$created_at
username = storm_tweets$user$screen_name
tweet_text = storm_tweets$text
# check the values
str(date_time)
str(username)
str(tweet_text)
# create a new data frame with the extracted information
storm <- data.frame(date_time, username, tweet_text)
# simple summary of the dataset
head(storm)
str(storm)
#Process date_time information, count number of tweets for each
#minute in the dataset.
str(date_time)
substr
substr("Tue Oct 07 00:00:01 +0000 2014", 1, 16)
table(substr(date_time,1,16))
