getwd()
adults <- read.csv("/Users/bernairemari/Desktop/Adults_Cleaned.csv")
#How many people have education ‘Bachelors’?
sum(adults$education== 'Bachelors')

#What is the percentage of people earn more than 50K?
(sum(adults$label== '>50K')/nrow(adults))*100

#For people who work more than 40 hours, what is the percentage of people earn more than 50K?
(sum(adults$label == '>50K')/sum(adults$hours.per.week >40))*100
