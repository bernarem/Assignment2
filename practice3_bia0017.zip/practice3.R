course.grades <- c(92, 78, 87, 69, 90, 54, 49, 75)
#Write a loop to print the grade of all students
for (i in course.grades){
  print(i)
}
#Write a loop with condition function inside. If a student has grade less than 60,
#print “failed”, otherwise print “pass”  
for (i in course.grades){
  if(i<60){
    print("failed")
  }
  else{print("pass")}
}
#Create a function to compute the area of a rectangle with length and width
Rec_area <- function(x,y){
  return(x*y)
}
Rec_area(5,7)

