getwd()
adults <- read.csv("/Users/bernairemari/Desktop/Adults_Cleaned.csv") 
#Check how many samples in the dataset?
nrow(adults)
#View the first 10 rows of the data
head(adults, 10)
#Get the data types for each column
str(adults)
#Get a summary of the data
summary(adults)
#Count how many people come from Cuba?
sum(adults$native.country== 'Cuba')
